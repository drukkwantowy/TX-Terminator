# Roadmap

## OpenBCI WiFi Shield Library

Make programming with OpenBCI reliable, easy, research grade and fun!

## Short term - what we're working on now

- UDP Streaming
- WiFi Direct

## Medium term

- MQTT Secure
